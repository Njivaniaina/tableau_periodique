/************************************************************************************
 * 																					*
 *   		AUTEUR : Sanda , Njiva, Andry, Christon									*	
 * 																					*
 * 			DESCRIPTION : Tableau périodique (Partie principale du programme) 		*
 * 																					*
 * 			DATE DE FINISSION : 27 Avril 2023										*
 * 																					*
 ***********************************************************************************/

///Rémarque:
    /********************************************************************************************************
     *                                                                                                      *
     *   Le variable mots c'est le varible qui contient tous les synonymes , en laguage choisie,            *
     *   de tous les mots utilisées dans le programme. On peut vérifier ou changer par la fichier           *       
     *   "language.txt" , les synonymes des mots                                                            *
     *                                                                                                      *
     ********************************************************************************************************/


#include <stdlib.h>
#include "loading.h"						//Contien le chargement "HELLO"
#include "exploiter.h"						//Contien les fonctions utiles dans le menu : exploitation , aide , ...	
#include "jeu.h"						//Contien tous les fonction concernant le petit jeu 
#include "data.h"							//Contien tous les données des atomes
#include "langue.h"

int main(int argc, char *argv[]){
	int exit=1;
	char nom[118][30];			//Pour le nom
	char symbole[118][5];		//Pour le symbole
	char description[118][100];	//Pour la nature
	int numero_atomique[118];	//Pour le numéro atomique
	float masse_atomique[118];	//Pour la masse atomique
	char mots[100][100];		//Pour mettre les mots en langue choisies
	char niveau[10];			//Pour le niveau du jeu
	int max=20;					//Pour le maximum dans le niveau du jeu, on l'initialise en facile c'est-à-dire max=20
	char fiteny[100]; 			//Pour le language

	hello();											//Pour lancer le hello de démarage
	data(nom, symbole, description, numero_atomique, masse_atomique);				//Pour avoir les données de tous les atomes
	mis_a_jour_de_langue(mots, fiteny);									//Mettre en place la language utilisées	

	if(argc == 2 || argc == 3){									//Vérifier si il y a des argument 
		if(strcmp(argv[1],"1") == 0)				//Si l'argument est '1', on saute dans le choix 1
			goto m1;
		else if(strcmp(argv[1],"2") == 0)				//Si l'argument est '2', on saute dans le choix 2
			goto m2;
		else if(strcmp(argv[1],"3") == 0)				//Si l'argument est '3', on saute dans le choix 3
			goto m3;
		else if(strcmp(argv[1],"4") == 0)				//Si l'argument est '3', on saute dans le choix 3
			goto m4;
		else{
			lettreRoulante("\e[31mArgument indisponible!!!\n\e[0m");
			sleep(3);
		}
	}	
	else if(argc > 3){								//Si l'argument  dépasse le 2, alors on dit qu'il y a trop
		lettreRoulante("Trot d'arrgument!!!\n");
		sleep(3);
	}
	
	while(exit){
		switch (menu(mots)){
			case '1':
			/**************************************************************************** 
			 *   cette partie est pour l'exploitation des atomes dans le memoire.		*
			 ****************************************************************************/
				m1:
					recherche_nom(nom, symbole, description, numero_atomique, masse_atomique, mots, argv, argc);
				break;
			
			case '2':
			/**************************************************************************** 
			 *   cette partie est pour les jeux du programme : mots ou nombre.			*
			 ****************************************************************************/
				m2:
					jeu(nom, symbole, description, numero_atomique, masse_atomique, mots, niveau, argv, argc, &max);
				break;
			
			case '3':
			/**************************************************************************** 
			 *   cette partie est pour la gestion de language du programme.				*
			 ****************************************************************************/
				m3:
					language(mots, argc, argv, fiteny);
				break;
			
			case '4':
			/**************************************************************************** 
			 *   cette partie est pour l'aide du programme.            					*
			 ****************************************************************************/
				m4:
				displayHelp(fiteny, mots);
				break;

			case '5':
				exit=0;							//On sort du Boucle et termine le programme si c'est finie
				break;
			
			default :
				displayError(mots);				//pour les choix indisponibles
				sleep(3);
				system("clear");
				break;
		}
	}
	
	return 0;
}
