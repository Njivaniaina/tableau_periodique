/************************************************************************************
 * 																					*
 *   		AUTEUR : Sanda , Njiva, Andry, Christon									*	
 * 																					*
 * 			DESCRIPTION : Tableau périodique (Partie de jeu: mot et nombre) 		*
 * 																					*
 * 			DATE DE FINISSION : 27 Avril 2023										*
 * 																					*
 * 			CONTENANT : Contenant tous les données de la language				    *
 * 																					*
 ***********************************************************************************/

///Rémarque:
    /********************************************************************************************************
     *                                                                                                      *
     *   Le variable mots c'est le varible qui contient tous les synonymes , en laguage choisie,            *
     *   de tous les mots utilisées dans le programme. On peut vérifier ou changer par la fichier           *       
     *   "language.txt" , les synonymes des mots                                                            *
     *                                                                                                      *
     ********************************************************************************************************/


void mis_a_jour_de_langue(char menu1[100][100], char *language){                                ///Pour le mis à jour de la langue dès le début et en chageons 
    FILE *dictionnaire = NULL;                                           //Mettre tous les traductions des mots utilisés dans tous le programme
    char phrases[300];                                    //Mettre le variable que l'on utilise pour avoir le synonyme dans le fichier et la 2eme c'est pour le langue utilisées par le systèmes
    char langue;                                                         //Marquée la langue utilisées : 1=Français, ...
    int n=0, i=0, l=0;                                                   //des varibles utiles : mettre le nombre de caractère, compteur, ...
    int nombre_de_menu=100;                                              //pour compter les mots que l'on  traduit dans tous le programme

    dictionnaire = fopen("/usr/local/src/language.txt", "r");                           //On ouvre le fichier
   
    if(dictionnaire != NULL){
        fgets(language, 100, dictionnaire);                              //On prend le première mots comme indicateur de langue
        l = strlen(language);
        language[l-1] = '\0';
        if(strcmp(language, "francais") == 0)                            //Pour la langue francais
            langue='1';
        if(strcmp(language, "malagasy") == 0)                            //Pour la langue malagasy
            langue='2';
        if(strcmp(language, "anglais") == 0)                            //Pour la langue anglais
            langue='3';
        switch(langue){
            case '1':                                               ///Si la langue est francais , alors on prend tous les synonyme francais de tous les mots dans le programme.
                for(int j=0; j<nombre_de_menu; j++){
                    n=0;
                    fgets(phrases, 300, dictionnaire);
                    l=0;
                    for( i=0; phrases[i] != '\n';i++ ){
                        if(n == 0 && phrases[i] != '='){            //Prendre tous les mots ou phrases en langue choisis
                            menu1[j][l]=phrases[i];
                            l++;
                        }
                        if( phrases[i] == '=' ){                     //Pour la langue choisie (francais qui est dès le début , alors n=0)
                            n--;
                        }
                    }
                    menu1[j][l]='\0';
                }
                break;

            case '2':                                                       ///Si la langue est malagasy , alors on prend tous les synonyme Malagasy de tous les mots dans le programme.
                for(int j=0; j<nombre_de_menu; j++){
                    n=1;
                    fgets(phrases, 300, dictionnaire);
                    l=0;
                    for( i=0; phrases[i] != '\n';i++ ){
                        if(n == 0 && phrases[i] != '='){                    //Prendre tous les mots ou phrases en langue choisis
                            menu1[j][l]=phrases[i];
                            l++;
                        }
                        if( phrases[i] == '='){                             //Pour la langue choisie (malagasy qui est dès le deuxième , alors n=1 nombre d'égal)
                            n--;
                        }
                    }
                    menu1[j][l]='\0';
                }
                break;

            case '3':                                                       ///Si la langue est anglais , alors on prend tous les synonyme anglais de tous les mots dans le programme.
                for(int j=0; j<nombre_de_menu; j++){
                    n=2;
                    fgets(phrases, 300, dictionnaire);
                    l=0;
                    for( i=0; phrases[i] != '\n';i++ ){                     //Prendre tous les mots ou phrases en langue choisis
                        if(n == 0 && phrases[i] != '='){
                            menu1[j][l]=phrases[i];
                            l++;
                        }
                        if( phrases[i] == '='){                              //Pour la langue choisie (anglais qui est dès le Troisième , alors n=2 nombres d'égals)
                            n--;
                        }
                    }
                    menu1[j][l]='\0';
                }
                break;

        }
        fclose(dictionnaire);
    }
    else {                                                                      ///si l'overture du fichier a échouée
        printf("Une erreur lors de l'ouverture du dictionnaire de language.\n");
    }
}

void change_language(char *langue){                                 //Pour changer la langue du programme
    FILE *doc=NULL, *doccopy = NULL;
    char text[300];

    doc = fopen("/usr/local/src/language.txt", "r");                               //On ouvre le fichier qui contient les synonyme par la mode "read"
    doccopy = fopen("/usr/local/src/temporaire.txt", "w");                         //Une fichier temporaire pour copier les synonymes
    if( doc != NULL && doccopy !=  NULL){                           //et on copie dans le fichier temporaire tous les synonymes des mots pour chager la langue du première ligne
        while(fgets(text, 300, doc) != NULL){
            fprintf(doccopy, "%s", text);
        }
        fclose(doccopy);                                            //On ferme tous les fichiers ouvertes
        fclose(doc);
    }
    else{                                                              //Au cas où le fichier n'est pas touvées
        printf("Erreur dans la copie 1 du fichier!!!!\n");
    }

    doc = fopen("/usr/local/src/language.txt", "w");                               //On réouvrt le fichier mais dans le sens qu'on écrit 
    doccopy = fopen("/usr/local/src/temporaire.txt", "r");                         //De même , on lit dans le fichier temporaire qu'on a mis les synonyme pour l'écrire a nouveau mais changer le première ligne
    if( doc != NULL && doccopy !=  NULL){
        fgets(text, 300, doccopy);
        fprintf(doc, "%s\n", langue);                               //On change le langue du première ligne
        while(fgets(text, 300, doccopy) != NULL){
            fprintf(doc, "%s", text);
        }
        remove("temporaire.txt");                                   //On efface le fichier temporaire 
        fclose(doccopy);                                            //On ferme tous les fichier ouvertes
        fclose(doc);
    }
    else{
        printf("Erreur dans la copie 2 du fichier!!!!\n");
    }
}

char menu_language(char mots[100][100]){												//C'est le menu du language
	char choix=0;
	char buffer[2];											//Le choix de la menu
	
	loading1(20);
	printf("\e[34m   ________________________________________________________\n");
	printf(" / \\                                                        \\.\n");
	printf("|  |         \e[31;1m _^_                            _^_\e[34m            |.\n");
	printf(" \\-|        \e[31;1m (___)==========================(___)\e[34m           |.\n");	
	printf("   |         \e[31;1m |_|     \e[31;1;5m      %s     \e[0m\e[31;1m    |_|\e[34m            |.\n", set(mots[61], 9));
	printf("   |         \e[31;1m(___)==========================(___)\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[1]=)======> %s <======(=[1]\e[34m           |.\n", set(mots[62], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[2]=)======> %s <======(=[2]\e[34m           |.\n", set(mots[63], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[3]=)======> %s <======(=[3]\e[34m           |.\n", set(mots[64], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[4]=)======> %s <======(=[4]\e[34m           |.\n", set(mots[13], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |   _____________________________________________________|____\n");
	printf("   |  /                                                         /.\n");
	printf("   \\-/_________________________________________________________/.\e[0m\n");
	printf("\n\t\e[36m");
	lettreRoulante(mots[6]);    	  	///Défiler le mot "Votre choix : "
	printf("\e[0m");
	lit(buffer, 2);
	choix = buffer[0];
	loading2(20);
	return choix;
}

void language(char mots[100][100], int argc, char *argv[], char *l){
	
	if(argc == 3){	                                                ///C'est pour l'argument 
		if (strcmp(argv[2], "1") == 0)
			goto m11;
		else if (strcmp(argv[2], "2") == 0)
			goto m12;
		else if (strcmp(argv[2], "3") == 0)
			goto m13;
	}

    revenir :										
	switch (menu_language(mots)){
		case '1':                                                   //si le choix est francais
            m11:
			change_language("francais");                            //On met en francais le ligne débutant le fichier language
            mis_a_jour_de_langue(mots, l);                          //On met à jour la lague choisie
			break;
		
		case '2':                                                   ///si la langue choisie est malagasy
            m12:											
			change_language("malagasy");                            //On met en malagasy le ligne débutant le fichier language
            mis_a_jour_de_langue(mots, l);                          //On met à jour la lague choisie
			break;
	
		case '3':                                                   ///si la langue choisie est anglais
            m13:											
			change_language("anglais");                             //On met en anglais le ligne débutant le fichier language
            mis_a_jour_de_langue(mots, l);                          //On met à jour la lague choisie
			break;

        case '4':                                                  //Pour le chois de retour.
        break;

		default :
			displayError(mots);										//C'est pour les choix indisponibles
			sleep(3);
			system("clear");
            goto revenir;                                          ///ON revien  des le début si le choix est indisponible
			break;
	}
}
