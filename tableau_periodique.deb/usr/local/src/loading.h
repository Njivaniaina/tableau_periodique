/************************************************************************************
 * 																					*
 *   		AUTEUR : Sanda , Njiva, Andry, Christon									*	
 * 																					*
 * 			DESCRIPTION : Tableau périodique (Partie de jeu: mot et nombre) 		*
 * 																					*
 * 			DATE DE FINISSION : 19 Avril 2023										*
 * 																					*
 * 			CONTENANT : Le programme qui affiche le "HELLO"							*
 * 																					*
 ***********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void initialise(char signe[9][37]);				
void displayS(char signe[9][37]);
void SC(long t);
void printH(char signe[9][37]);
void affectation(char signe[9][37]);
void correct(char signe[9][37]);

void hello() {
    char signe[9][37];
    initialise(signe);                               //On initialise le tableau et change le soit disons rectangle
    
    printH(signe);									//On affiche l'entrer du mot HELLO
    affectation(signe);								//On fait clignotant
    correct(signe);									//On refait en normal
}
void initialise(char signe[9][37]){					//Initialiser chaque cage du colone en du ligne
	for(int j=0; j < 9; j++){
		for(int i=1; i<36 ; i++){					///Tous mettre en espace...
			signe[j][i]=32;
		}
		signe[j][0]='*';							///Sauf tous les 1ere ligne
		signe[j][36]='\0';							//On termine par le caractère NULL
	}
	signe[0][1]='*';
	signe[8][1]='*';
}

void displayS(char signe[9][37]){				///Afficher tous les lignes et les colones
	for (int j=0; j<9 ; j++){
		printf("\t\t\t\t%s", signe[j]);
		putchar('\n');
	}
}

void SC(long t){  									///Pour mettre en pause pendant des fractions de secondes notre programme à chaque changement
	usleep(t);									//Le temps de pause en nano seconde
    system("clear");							//Puis on l'efface
}

void printH(char signe[9][37]){									///Pour l'affichage 
	for (int i=0, l=0; i < 37 ; i++, l++){
		
		printf("\n\n\n\n\e[38;2;0;255;0m");						//On change le couleur avant d'afficher
        displayS(signe);										//On l'affiche
        SC(30000);												//Et on met en pause
        for(int k=1; k<8; k++){
			signe[k][l+1]=32;
			signe[k][l+2]='*';
			signe[0][l+2]='*';
			signe[8][l+2]='*';
		}
		if (i == 3 || i == 7 || i == 9 || i == 14 || i == 20 || i == 26 || i == 30){
			for (int l=2; l<7 ; l++){								//Pour chaque bares verticale dans le lettre , on les positions par cette boucle
				signe[l][i]='*';
			}
		}
		if ((i > 3 && i < 7) || (i > 9 && i < 11)){
			signe[4][i]='*';										//Pour chaque bares horizontale au centre, on ajoute ces bares pendant l'ouverture
		}
		if ((i > 9 && i < 13) || (i > 25 && i < 31)){				//Pour chaque bares horizontale à part le dessus, on les met là une partie
			signe[2][i]='*';
			signe[6][i]='*';
		}
		if ((i >  14 && i < 19) || ((i > 19 && i < 25))){			//... Et là l'autre partie
			signe[6][i]='*';										
		}
		if (i == 31){                                             	//On sort du boucle quand le nombre est atteind 
			break;
		}
    }
}

void affectation(char signe[9][37]){							///Pour faire croire que les étoiles se tourne en rond, on affiche les positions de la même façon aleatoire en paire  impaire
	for (int a=0; a<30; a++){
		printf("\n\n\n\n\e[38;2;0;255;0m");					//Changement de couleur et mettre en place sa position
		displayS(signe);									//Fonction affichage à chaque passage dans se boucle
		SC(100000);											//Un petit pause 
		if((a%2) == 0){									///Là , les changement se fait en deux phase, On affiche d'abord les tableaux qui on des indices pairs
			for (int i=0; i < 33; i++){					
				if (i%2 == 0){							//Pour le colone, on masque les paires		
					signe[0][i]=32;
					signe[8][i]=32;
				}
				if (i%2 != 0){							//Pour le colone, on affiche le reste
					signe[0][i]='*';
					signe[8][i]='*';
				}
			}	
			for (int j=0; j<9 ; j++){					//pour le ligne, On masque les tableaux impaire
				if(j%2 != 0 ){
					signe[j][0]=32;
					signe[j][33]=32;
				}
				if(j%2 == 0 ){								//pour le lignes, On affiche le reste
					signe[j][0]='*';
					signe[j][33]='*';
				}
			}	
			
		}
		if((a%2) != 0){										///De ce fait, la deuxième phase est que on renverse la 1ere
			for (int i=0; i < 33; i++){
				if (i%2 != 0){								//Dans le colone , masque tous les tableaux impaire
					signe[0][i]=32;
					signe[8][i]=32;
				}	
				if (i%2 == 0){								//On affiche le reste
					signe[0][i]='*';
					signe[8][i]='*';
				}
			}
			for (int j=0; j<9 ; j++){						//Pour le colone aussi, On met au contraire , on masque les paires
				if(j%2 == 0){
					signe[j][0]=32;
					signe[j][33]=32;
				}
				if(j%2 != 0 ){								//Et on affiche les impaires
					signe[j][0]='*';
					signe[j][33]='*';
				}
			}
		}
	}
}

void correct(char signe[9][37]){						///Les balises pour remettre en place  tous les étoiles à la fin de l'affectation en boucle
	for(int i=0; i < 34; i++){						//Remettre les colones
		signe[0][i]='*';			
		signe[8][i]='*';
	}
	for(int i=0; i < 9; i++){						//Remettre les lignes
		signe[i][0]='*';
		signe[i][33]='*';
	}
}
