/************************************************************************************
 * 																					*
 *   		AUTEUR : Sanda , Njiva, Andry, Christon									*	
 * 																					*
 * 			DESCRIPTION : Tableau périodique (Partie de jeu: mot et nombre) 		*
 * 																					*
 * 			DATE DE FINISSION : 27 Avril 2023										*
 * 																					*
 * 			CONTENANT : Contenant tous les données du jeu					        *
 * 																					*
 ***********************************************************************************/

 ///Rémarque:
    /********************************************************************************************************
     *                                                                                                      *
     *   Le variable mots c'est le varible qui contient tous les synonymes , en laguage choisie,            *
     *   de tous les mots utilisées dans le programme. On peut vérifier ou changer par la fichier           *       
     *   "language.txt" , les synonymes des mots                                                            *
     *                                                                                                      *
     ********************************************************************************************************/


#include <time.h>

int randomN(int max){								///Pour le nombre tirer au hasard des numéro atimique de l'atome
	int number=0;
	srand(time(NULL));
	number=(rand()%(max-0+1)-0);
	return number;									//on utilise la valeur de retoure
}

int win(int *w, int n){								///Pour vérifier si l'on a trouvée le mot ou pas
	int t=1;
	for(int i=0;i<n;i++){
		if( *(w+i) == 0){							///Si il y a encore de lettre non trouver , alors on continue le boucle while(1)
			t=0;
		}
	}
	return t;										//on met la valeur du retoure de 1 si l'on a trouvée pour arrêter le boucle while(1)
}

void analyse1(char word[10], int* w ,char letter, int n, int *coups){					///Pour verifier si un lettre est dans le mot
	int trues=0;
	
	for(int i=0;i<n;i++){
		if(letter == word[i]){						//Si le lettre est dans le mot , alors on met 1 la valeur de tableau de verification
			w[i]=1;
			trues=1;
		}
	}
	if(trues != 1){									// Sinon on ne change rien et on diminue le nombre de coups
		(*coups)-=1;
	}
}

char readLetter(){									///Pour lire un lettre 
	char word='\n';
	
	//word = getchar();
	while ((word = getchar()) == '\n' );			//Pour éviter les entrers vide
	word = toupper(word);							//On met en majuscule le lettre pour comparer à celle du mot
	
	return word;
}

char menu_jeu(char mots[100][100]){									///Menu du jeu 
	char choix=0;
	char buffer[2];

	loading1(20);									//Une petite chargement
	printf("\e[34m   ________________________________________________________\n");
	printf(" / \\                                                        \\.\n");
	printf("|  |         \e[31;1m _^_                            _^_\e[34m            |.\n");
	printf(" \\-|        \e[31;1m (___)==========================(___)\e[34m           |.\n");	
	printf("   |         \e[31;1m |_|          \e[31;1;5m%s\e[0m\e[31;1m         |_|\e[34m            |.\n", set(mots[35], 10));
	printf("   |         \e[31;1m(___)==========================(___)\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[1]=)======> %s <======(=[1]\e[34m           |.\n", set(mots[9], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[2]=)======> %s <======(=[2]\e[34m           |.\n", set(mots[10], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[3]=)===> %s <===(=[3]\e[34m           |.\n", set(mots[11], 16));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[4]=)===> %s <===(=[4]\e[34m           |.\n", set(mots[12], 16));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[5]=)===> %s <===(=[5]\e[34m           |.\n", set(mots[69], 16));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |                                                        |.\n");
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |          \e[33m[6]=)======> %s <======(=[6]\e[34m           |.\n", set(mots[13], 10));
	printf("   |          \e[33m***********************************\e[34m           |.\n");
	printf("   |   _____________________________________________________|____\n");
	printf("   |  /                                                         /.\n");
	printf("   \\-/_________________________________________________________/.\e[0m\n");
	printf("\n\t\e[36m");
	lettreRoulante(mots[6]);    	  	///Défiler le mot "Votre choix : "
	printf("\e[0m");
	lit(buffer, 2);
	choix = buffer[0];
	system("clear");  
	loading2(28);										//Une petite chargement
	return choix;
}

void dispaly1(char word[10], int* w, int n, int coups, char mots[100][100]){				///Pour le jeu de mots
	int i = 0;
	printf("\n\e[33m%s%d%s\n",mots[40], coups, mots[41]);					//On affiche le nombre de coups
	printf("%s\e[31m", mots[42]);									 
	for(i=0; i<n; i++){
		if (w[i]){
			printf("%c",word[i]);									//On affiche les lettres trouvées
		}
		else{
			printf("*");											//sinon on affiche un étoile
		}
	}
	printf("\e[36m\n%s\e[0m", mots[43]);						//Et on demande d'enter un lettre
}

void indice1(char *description, char *symbole, int coups, int numero_atomique, float masse_atomique, int n, int i, int *j, char mots[100][100]){						///Pour l'indice sur l'atome à deviner
	if(coups == 2*n && (*j) == 2){									//La première indice c'est la déscription, on L'affiche part le fonction de deroulage
		lettreRoulante("\e[32m");
		lettreRoulante(mots[44]);
		printf("\e[34m");
		lettreRoulante(description);
		lettreRoulante("\e[32m.\n");
		lettreRoulante(mots[45]);
		printf("%d", coups);
		lettreRoulante(mots[41]);
		printf("\e[0m\n\n");
		(*j)--;
	}
	
	/***************************************************************************************
		Le variable i est pour indique si c'est un jeu de nom ou c'est un jeu de numero.
	****************************************************************************************/
	
	if (coups == n && i && (*j) == 1){								//Pour la 2eme indice, on affiche le numéro et la masse atimique de l'atome pour le devinette nom
		lettreRoulante("\e[32m");
		lettreRoulante(mots[46]);
		lettreRoulante("\n");
		lettreRoulante(mots[47]);
		printf("\e[31m");
		printf("%f", masse_atomique);
		lettreRoulante("\e[32m");
		lettreRoulante(mots[48]);
		printf("\e[31m");
		printf("%d", numero_atomique);
		lettreRoulante(".\e[0m\n\n");
		(*j)--;
		
	}
	if (coups == n && !i && (*j) == 1){								//Pour le 2eme indice de devine numéro ,on affiche le symbole
		lettreRoulante("\e[32m");
		lettreRoulante(mots[46]);
		lettreRoulante("\n");
		lettreRoulante(mots[47]);
		lettreRoulante(mots[49]);
		printf("\e[31m");
		lettreRoulante(symbole);
		lettreRoulante(".\e[0m\n\n");
		(*j)--;
	}
}

void resultat(int coups, char *word, char *atome, int n, char mots[100][100]){			///C'est pour dire si l'on a gagné ou non
	if( coups != 0){
		printf("\n\n\t\t\e[33;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("\t\t||        \e[33;1;5m %s \e[0m\e[33;1m     ||\n", set(mots[50], 15));
		printf("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		lettreRoulante("\t\t        ");
		lettreRoulante(mots[51]);
		printf("\e[31m");			
		lettreRoulante(word);										//Disons aussi le MOT
		printf(".\e[33m     \n");
		if(n){
			lettreRoulante("\t\t        ");
			lettreRoulante(mots[52]);
			printf("\e[31m");                                               		///C'est pour le devine numéro ou masse atomique pour afficher à la fin le nom de l'atome
			lettreRoulante(atome);
			printf(".\e[33m.             \n\n\e[0m");
		}
	}
	if(coups == 0){													//On affiche "Game Over", si le joueur perd
		printf("\n\n\t\t\e[33;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("\t\t||         \e[33;1;5m%s\e[0m\e[33;1m        ||\n", set(mots[53], 14));
		printf("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		lettreRoulante("\t\t        ");
		lettreRoulante(mots[51]);
		printf("\e[31m");
		lettreRoulante(word);										//Et aussi, on donne le MOT
		printf(".\e[33m     \n");
		if(n){														///C'est aussi pour le devine numéro ou masse atomique pour afficher à la fin le nom de l'atome dans le cas que le joueur perd
			lettreRoulante("\t\t        ");
			lettreRoulante(mots[52]);
			printf("\e[31m");  
			lettreRoulante(atome);
			printf(".\e[33m             \n\n\e[0m");
		}
	}
}

void getnum(int *number, char mots[100][100]){											///Lire un nombre taper par joueur ou joueuse
	char n[5];
	lit(n, 5);
	while((*number = atoi(n)) == 0){								//Vérifier bien si c'est bien un nombre
		printf("\e[41m%s\e[0m\n", mots[54]);
		lit(n, 5);
	}
}

void analyse2(int n, int num, int* c, char mots[100][100]){								///Pour aider dans le jeu de deviner un nombre
	if(n>num){
		printf("\e[31m%s\e[0m\n\n", mots[55]);						//On dit si il est moins que la bonne
		(*c)--;														//Et on diminue le coups
	}
	else if(n<num){
		printf("\e[31m%s\e[0m\n\n", mots[56]);						//On dit si il est plus que la bonne
		(*c)--;														//Et on diminue le coups
	}
}

void display2( int n, int m, char *nom, char mots[100][100]){							///Dire si l'on a gagné dans le jeu de deviner le numéro atomique de l'atome
	if( n == m ){													//Soit il gagne, on affiche l'atome
		lettreRoulante("\n\e[32m");
		lettreRoulante(mots[57]);
		printf("\n");
		printf(mots[52]);
		printf("\e[31m");
		lettreRoulante(nom);
		lettreRoulante("\e[32m");
		lettreRoulante(mots[48]);
		printf("\e[31m");
		printf("%d", n);
		lettreRoulante(".\e[0m\n");
	}
	else if(n!=m){													//Soit il pert, on affiche l'atome
		lettreRoulante("\n\e[32m");
		lettreRoulante(mots[59]);
		printf("\n");
		printf(mots[52]);
		printf("\e[31m");
		lettreRoulante(nom);
		lettreRoulante("\e[32m");
		lettreRoulante(mots[48]);
		printf("\e[31m");
		printf("%d", n);
		lettreRoulante(".\e[0m\n");
	}
}

void display3(int coups, float n, char *nom, char mots[100][100]){						///Ceci est pour le résultat du jeu de deviner la masse atomique d'un atome
	if(coups){														//Soit il gagne
		lettreRoulante("\n\e[32m");
		lettreRoulante(mots[57]);
		printf("\n");
		printf(mots[52]);
		printf("\e[31m");
		lettreRoulante(nom);
		lettreRoulante("\e[32m");
		lettreRoulante(mots[58]);
		printf("\e[31m");
		printf("%f", n);
		lettreRoulante(".\e[0m\n");
	}
	else if(!coups){												//Soit il pert
		lettreRoulante("\n\e[32m");
		lettreRoulante(mots[59]);
		printf("\n");
		printf(mots[52]);
		printf("\e[31m");
		lettreRoulante(nom);
		lettreRoulante("\e[32m");
		lettreRoulante(mots[58]);
		printf("\e[31m");
		printf("%f", n);
		lettreRoulante(".\e[0m\n");
	}
}

void subTitle(int c, char mots[100][100]){	
	printf("\n\e[33m%s%d%s\n",mots[40], c, mots[41]);							///Dire le nombre de coups et de taper un nombre dans les jeux de devine nombre (numéro et masse atomique)
	printf("%s\e[0m", mots[60]);
}

char menu_niveau(char mots[100][100], char *niveau, int *max){								///définir le menu de choix de niveaux
	char buffer[2];
	char choix=0;
	
	if((*max) == 20){								///Pour le niveau que l'on affiche dans le choix niveau "Facile"
		strcpy(niveau, mots[66]);
	}
	else if((*max) == 60){
		strcpy(niveau, mots[67]);					///Pour le niveau que l'on affiche dans le choix niveau "moyenne"
	}
	else if((*max) == 118){
		strcpy(niveau, mots[68]);					///Pour le niveau que l'on affiche dans le choix niveau "Difficile"
	}

	printf("\t\t    \e[44m                             \e[0m\n");
	printf("\t\t    \e[41m                             \e[0m\n");
	printf("\t\t    \e[41;6m        %s         \e[0m\n", set(mots[65], 13));
	printf("\t\t    \e[41m                             \e[0m\n");
	printf("\t\t    \e[44m                             \e[0m\n");
	printf("\t\t\e[0m\t\n");
	printf("\t\t\e[41m\t                      \e[0m\n");
	printf("\t\t\e[41m\t  [1] : %s     \e[0m\n", set(mots[66], 10));
	printf("\t\t\e[41m\t                      \e[0m\n");
	printf("\t\t\e[0m\t\n");
	printf("\t\t\e[41m\t                      \e[0m\n");
	printf("\t\t\e[41m\t  [2] : %s     \e[0m\n", set(mots[67], 10));
	printf("\t\t\e[41m\t                      \e[0m\n");
	printf("\t\t\e[0m\t\n");
	printf("\t\t\e[41m\t                      \e[0m\n");
	printf("\t\t\e[41m\t  [3] : %s     \e[0m\n", set(mots[68], 10));
	printf("\t\t\e[41m\t                      \e[0m\n\n\n");
	lettreRoulante("\e[43m\t");
	lettreRoulante(mots[70]);
	lettreRoulante(niveau);
	lettreRoulante(".\e[0m\n");
	printf("\t\t\e[0m\t\n");
	printf("\n\t\e[36m");
	lettreRoulante(mots[6]);    	  	///Défiler le mot "Votre choix : "
	printf("\e[0m");
	lit(buffer, 2);
	choix = buffer[0];
	system("clear");
	return choix;
}

int niveau(char *niveaux, char mots[100][100], int *m){								///pour le differente niveau dans le jeu
	int max;
	
	switch (menu_niveau(mots, niveaux, m)){
		
		case '1' : {
			max = 20;														///Pour le niveau facile, on décider de mettre max=20 atomes
			strcpy(niveaux, mots[66]);	
			break ;
		}
		case '2' : {
			max = 60;														///Pour le niveau Moyen, on décider de mettre max=60 atomes
			strcpy(niveaux, mots[67]);	
			break ;
		}		
		case '3' : {
			max = 118;														///Pour le niveau Difficile, on décider de mettre max=tous les atomes
			strcpy(niveaux, mots[68]);
			break ;
		}
		default :{
			printf("\e[41m	    %s    \e[0m                            \n", set(mots[32], 23));
			sleep(3);
			break;
		}
	}
	return max;
}

void jeu(char nom[118][30], char symbole[118][5], char description[118][100], int numero_atomique[118], float masse_atomique[118], char mots[100][100], char *niveaux, char *argv[], int argc, int *max){
	int *w=0;														//Pour la verification des lettres trouvées dans les jeux de mot
	char letter=0, ch[100];											//pour le lettre taper et pour le variable dans le system pause qu'on a créer
	char word[30];													//Pour le mot(nom ou symbole)
	int randomNumber=0,												//Le nombre tirer au hasard 
		coups=10,													//Le nombre de coups dans les jeux
		n=0,														//Permet de stoquer le nombre de lettre dans le mots
		nombre=0,													//Stoquer le nombre taper par le joueur ou le joueuse
		exit=1;														//Le quitte du Jeu
	int j=0;														//Pour marquer le prémière indice et le deuxième indice

	if(argc == 3){		
		if (strcmp(argv[2], "1") == 0)
			goto m21;
		else if (strcmp(argv[2], "2") == 0)
			goto m22;
		else if (strcmp(argv[2], "3") == 0)
			goto m23;
		else if (strcmp(argv[2], "4") == 0)
			goto m24;
		else if (strcmp(argv[2], "5") == 0)
			goto m25;
	}

	while(exit){													///Tant qu'on ne quitter pas le jeu ,on affiche le menu
		if((*max) == 20){								///Pour le niveau que l'on affiche dans le choix niveau "Facile"
			strcpy(niveaux, mots[66]);
		}
		else if((*max) == 60){
			strcpy(niveaux, mots[67]);					///Pour le niveau que l'on affiche dans le choix niveau "moyenne"
		}
		else if((*max) == 118){
			strcpy(niveaux, mots[68]);					///Pour le niveau que l'on affiche dans le choix niveau "Difficile"
		}

		switch(menu_jeu(mots)){
			case '1':												//1ere jeu: Deviner le nom de l'atome
				m21:
				printf("\e[32m");
				lettreRoulante(mots[36]);
				printf("\n\e[0m");
				randomNumber=randomN(*max);							//On Choisie au hasard le numéro atomique d'un atome	
				strcpy(word, nom[randomNumber]);					//On met dans la variable de mot
				n=strlen(word);										//On compte le nombre des lettres dans le mot
				for(int i=0;i<n;i++){
					word[i]=toupper(word[i]);						///On met tous les lettres dans le mot pour faciliter la verification d'un lettre taper
				}
				coups=10;											//initialiser le nombre de coups
				j=2;												//On marque le 1ere indice par le 2 et puis il va être en 1 pour le 2eme indice
				w = (int*)malloc(sizeof(int)*n);						
	
				for(int i=0;i<n;i++){
					w[i]=0;											//initialiser le nombre dans la variable de vérification en 0
				}
		
				while(!win(w, n) && coups != 0){					///Tant que on n'a pas trouver ou qu'on a de coups , on continue	(while(1))
					indice1(description[randomNumber], symbole[randomNumber], coups, numero_atomique[randomNumber], masse_atomique[randomNumber], 5, 1, &j, mots); 		//On dit le premier indice le début et le deuxième au miliue du jeu
					dispaly1(word, w, n, coups, mots);					//On affiche les lettres trouvées ou des étoiles
					letter=readLetter();							//On lit un lettres
					analyse1(word, w, letter, n, &coups);			//On verifie si le lettre correspond à un lettre dans le mot
				}
				resultat(coups, word, nom[randomNumber], 0, mots);						///On affiche les résultat
				lettreRoulante(mots[31]);					//On met en pause, pour le regarder
				lit(ch, 100);
				system("clear");
				free(w);
			break;
				
			case '2':												//2eme jeu: Deviner le Sybole de l'atome
				m22:
				/**************************************************************************************
				 * C'est de la même manière que le précedent , mais juste là , on devine une symbole  *
				 **************************************************************************************/
				 
				printf("\e[32m");
				lettreRoulante(mots[37]);
				printf("\n\e[0m");
				randomNumber=randomN(*max);
				strcpy(word, symbole[randomNumber]);
				n=strlen(word);
				for(int i=0;i<n;i++){
					word[i]=toupper(word[i]);
				}
				coups=4;											///On met juste 4 coups car on recherche juste 1 ou 2 lettres
				j=2;												//On marque le 1ere indice par le 2 et puis il va être en 1 pour le 2eme indice
				w = (int*)malloc(sizeof(int)*n);
	
				for(int i=0;i<n;i++){
					w[i]=0;
				}
		
				while(!win(w, n) && coups != 0){
					indice1(description[randomNumber], symbole[randomNumber], coups, numero_atomique[randomNumber], masse_atomique[randomNumber], 2, 1, &j, mots);
					dispaly1(word, w, n, coups, mots);
					letter=readLetter();
					analyse1(word, w, letter, n, &coups);
				}
				resultat(coups, word, nom[randomNumber], 1, mots);
				lettreRoulante(mots[31]);				//On met en pause, pour le regarder
				lit(ch, 100);
				system("clear");
				free(w);
			break;
			
			case '3':
				m23:
				printf("\e[32m");
				lettreRoulante(mots[38]);
				printf("\n\e[0m");
				randomNumber=randomN(*max);
				coups = 6;																//Initialiser le coups en 6 pour le devine nombre
				j=2;																	//On marque le 1ere indice par le 2 et puis il va être en 1 pour le 2eme indice
				while(coups != 0 && nombre != numero_atomique[randomNumber]){			///Tant que le nombre de coups n'est pas 0 ou le nombre n'est pas trouver , on fait :
					indice1(description[randomNumber], symbole[randomNumber], coups, numero_atomique[randomNumber], masse_atomique[randomNumber], 3, 0, &j, mots);
					subTitle(coups, mots);													//Dire le nombre de coups et de taper un nombre 
					getnum(&nombre, mots);													//lire le nombre taper 
					analyse2(nombre, numero_atomique[randomNumber], &coups, mots);			//analyser le nombre taper si plus ou moins ou égale
				}
				display2( numero_atomique[randomNumber], nombre, nom[randomNumber], mots);    //dire si le joueur à gagner ou pas
				lettreRoulante(mots[31]);					//On met en pause, pour le regarder
				lit(ch, 100);
				system("clear");
			break;
			
			case '4':
				m24:
				printf("\e[32m");
				lettreRoulante(mots[39]);
				printf("\n\e[0m");
				randomNumber=randomN(*max);
				coups = 6;
				j=2;																		//On marque le 1ere indice par le 2 et puis il va être en 1 pour le 2eme indice
				while(coups != 0 && fabs(nombre-masse_atomique[randomNumber])>1){			///Tant que le nombre de coups n'est pas 0 ou le nombre n'est pas trouver , on fait :
					indice1(description[randomNumber], symbole[randomNumber], coups, numero_atomique[randomNumber], masse_atomique[randomNumber], 3, 0, &j, mots);
					subTitle(coups, mots);														//Dire le nombre de coups et de taper un nombre 
					getnum(&nombre, mots);														//lire le nombre taper 
					analyse2(nombre, masse_atomique[randomNumber], &coups, mots);					//analyser le nombre taper si plus ou moins ou égale
				}
				display3(coups, masse_atomique[randomNumber], nom[randomNumber], mots);    	    //dire si le joueur à gagner ou pas
				lettreRoulante(mots[31]);						//On met en pause, pour le regarder
				lit(ch, 100);	
				system("clear");
			break;

			case '5':
				m25:
				*max = niveau(niveaux, mots, max);												///Pour le niveau dans le jeu
			break;
			
			case '6':
				exit=0;																		///Pour le retour au menu principale
			break;
			
			default :																		///Eviter que le joueur tape n'importe quoi pendant le choix
				displayError(mots);
				sleep(3);
				system("clear");
			break;
		}
	}
}
